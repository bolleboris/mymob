<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


//check if BMUCore exists already

if(!class_exists('BMUCore')) {
   //include BMUCore
   include_once('./BMUCore.php');
}

?>
